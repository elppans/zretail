#!/bin/bash

if [ "$(id -u)" != "0" ]; then
echo "Deve executar o comando como super usuario!"
exit 0
fi

LOCAL=`pwd`

if [ ! "$LOCAL" == "/opt" ] ; then
	echo "O instalador deve estar na pasta /opt!"
	sleep 2
	exit 0
fi

if [ -f /Zanthus/Zeus/Manager/ZMWSInfo.ini ] ; then
	ZMWSINFO='/Zanthus/Zeus/Manager/ZMWSInfo.ini'
  elif [ -f /usr/local/apache2/htdocs/manager/ZMWSInfo.ini ] ; then
	ZMWSINFO='/usr/local/apache2/htdocs/manager/ZMWSInfo.ini'
  elif [ -f /usr/local/apache2/htdocs/manager/includes/ZMWSInfo.ini ] ; then
	ZMWSINFO='/usr/local/apache2/htdocs/manager/includes/ZMWSInfo.ini'
  elif [ -f /usr/local/apache2/htdocs/../cgi-bin/ZMWSInfo.ini ] ; then
	ZMWSINFO='/usr/local/apache2/htdocs/../cgi-bin/ZMWSInfo.ini'
  elif [ -f /manager/ZMWSInfo.ini ] ; then
	ZMWSINFO='/manager/ZMWSInfo.ini'
  elif [ -f /usr/local/apache2/htdocs/ZMWSInfo.ini ] ; then
	ZMWSINFO='/usr/local/apache2/htdocs/ZMWSInfo.ini'
  elif [ -f /usr/local/apache2/htdocs/cgi-bin/ZMWSInfo.ini ] ; then
	ZMWSINFO='/usr/local/apache2/htdocs/cgi-bin/ZMWSInfo.ini'
		else
		echo -e '
	Arquivo ZMWSInfo.ini não encontrado nos diretórios ./

		/usr/local/apache2/htdocs/manager/includes

		/usr/local/apache2/htdocs/manager/
		/Zanthus/Zeus/Manager/
		/usr/local/apache2/htdocs/../cgi-bin/
		/manager/
		/usr/local/apache2/htdocs/
		/usr/local/apache2/htdocs/cgi-bin
'
	exit 0
fi

grep -E '\[.*\]|#' -v "$ZMWSINFO" | sed 's,\r, ,' | tee /etc/ZMWSInfo.env 1>> /dev/null
source /etc/ZMWSInfo.env

##	ZMWSInfo.ini > environment - FIM

echo -e "\nExecutando CONFIGURACAO do PostgreSQL e Compartilhamento...\n"
sleep 5

 sed -i "/SELINUX=/s/permissive/disabled/g" /etc/selinux/config
 sed -i "/SELINUX=/s/enforcing/disabled/g" /etc/selinux/config


## Variáveis para postgresql

# Aplicação:
export PGDATA="$(rpm -ql `rpm -qa | grep -E "postgresql.*server"` | grep -E "var.*pgsql.*data")"
export PGSERV="$(basename $(rpm -ql `rpm -qa | grep -E "postgresql.*server"` | grep -E "postgresql.*service"))"
export PGCHKC="$(basename $(rpm -ql `rpm -qa | grep -E "postgresql.*server"` | grep -E "postgresql.*service") | cut -d "." -f "1")"
export PGBIN=`ls -d /usr/pgsql*/b*/ | head -1`
export PGLIB='/usr/pgsql-10/lib/'

echo -e "$PGLIB" | tee /etc/ld.so.conf.d/instant_client.conf >> /dev/null

## Variáveis para postgresql

### RC.LOCAL
chmod +x /etc/rc.d/rc.local
### RC.LOCAL

### SAMBA

# sambashare
groupadd sambashare
mkdir -p /var/lib/samba/usershare
chown root.sambashare /var/lib/samba/usershare
chmod 1770 /var/lib/samba/usershare

#No arquivo /etc/samba/smb.conf, adicionar as linhas no GLOBAL:

#usershare path = /var/lib/samba/usershare
#usershare max shares = 100
#usershare allow guests = yes
#usershare owner only = no

# sambashare


## Samba

### smbname=zanthus
export smbname=zanthus
if ( cat /etc/passwd | grep zanthus )
			then
	echo -e "Configurando usuario "$smbname" em sambashare..."
	echo -e ""$smbname"\n"$smbname"" | smbpasswd -s -a "$smbname"
	usermod -a -G sambashare "$smbname"
			else
	echo -e "Criando e configurando usuario "$smbname" em sambashare..."
	adduser "$smbname"
	echo -e ""$smbname"\n"$smbname"" | passwd "$smbname"
	echo -e ""$smbname"\n"$smbname"" | smbpasswd -s -a "$smbname"
	usermod -a -G sambashare "$smbname"
	read -t 30
fi
### smbname=zanthus

### SAMBA rnolimit
if ! grep "* - nofile 16385" /etc/security/limits.conf ; then
echo -e "* - nofile 16385\n" | tee -a /etc/security/limits.conf >> /dev/null
fi
ulimit -Hn 16385
ulimit -Sn 16385
### SAMBA rnolimit

### Restart SAMBA
chkconfig nmb on
chkconfig smb on
systemctl enable nmb smb
systemctl stop nmb smb  >> /dev/null
systemctl start nmb smb
### Restart SAMBA

### SAMBA FIM

###		Compartilhamento

mkdir -p /Public
mkdir -p /Zanthus/Zeus/path_comum/EXISTE
mkdir -p /usr/local/apache2/htdocs/manager/Arquivos/1/VENDAS
mkdir -p /usr/local/apache2/htdocs/manager/Arquivos/1/Cupons
chmod -R a+rwxs /Public
chmod -R a+rwxs /Zanthus/Zeus/path_comum
chmod -R a+rwxs /usr/local/apache2/htdocs/manager
chown -R zanthus.zanthus /usr/local/apache2/htdocs/manager
chown -R zanthus.zanthus /Zanthus/Zeus/path_comum


###		Fim Compartilhamento

## Manager
mkdir -p /Zanthus/Zeus/Manager
ln -sf /usr/local/apache2/htdocs/manager/ZMWSInfo.ini /Zanthus/Zeus/Manager/ZMWSInfo.ini
## Manager

## Firewall
systemctl disable firewalld
systemctl stop firewalld
iptables -F

#Adicionar em rc.local:
if ( grep "iptables -F" /etc/rc.local ); then
	echo ""
  else
echo -e 'iptables -F' >> /etc/rc.local
fi
## Firewall

### UPGSQL=postgres


if ( cat /etc/passwd | grep "$User" )
			then
	echo -e ""$Passwd"\n"$Passwd"" | passwd "$User"
	chown -R "$User"."$User" /var/lib/pgsql
			else
	adduser "$User"
	echo -e ""$Passwd"\n"$Passwd"" | passwd "$User"
	chown -R "$User"."$User" /var/lib/pgsql
fi
### UPGSQL=postgres

# data
#if [ -d /var/lib/pgsql/data ];then
#	rm -rf /var/lib/pgsql/data
#	ln -sf "$PGDATA" /var/lib/pgsql/data
#	rm -rf /var/lib/pgsql/data/*
#  else
# if [ -d  "$PGDATA" ];then
#	ln -sf "$PGDATA" /var/lib/pgsql/data
#	rm -rf /var/lib/pgsql/data/*
#   else
#	echo "Não existe a pasta data..."
#	exit 0
#fi
#fi

if [ -d /var/lib/pgsql/data ];then
if [ "$PGDATA" == "/var/lib/pgsql/data" ]; then
	chown -R "$User"."$User" /var/lib/pgsql
	rm -rf /var/lib/pgsql/data/*
  else
 	rm -rf /var/lib/pgsql/data
	ln -sf "$PGDATA" /var/lib/pgsql/data
	rm -rf /var/lib/pgsql/data/*
fi
  else
 if [ -d  "$PGDATA" ];then
	ln -sf "$PGDATA" /var/lib/pgsql/data
	rm -rf /var/lib/pgsql/data/*
   else
	echo "Não existe a pasta data..."
	exit 0
fi
fi

# data

###		Adição  LCODING postgres-9.6
if [ -d "$PGBIN" ]; then
  if ( cat /etc/passwd | grep "$User" )
			then
		export PATH="$PGBIN":"$PATH"
		echo "env LANG=LATIN1 `which initdb` --locale=pt_BR.iso88591 --encoding=LATIN1 -D $PGDATA" | tee -a /var/lib/pgsql/.bash_profile
		export LC_ALL="pt_BR.iso88591"
		export LC_MESSAGES="pt_BR.iso88591"
		su "$User" -c "env LANG=LATIN1 `which initdb` --locale=pt_BR.iso88591 --encoding=LATIN1 -D /var/lib/pgsql/data"
    else
	echo -e "Não foi possível configurar codificação ao postgres, usuario nao existe!"
	echo -e "Crie o usuário postgres manualmente e execute novamente o comando $0..."
	exit 0
  fi
  else
	echo -e "(Re)Instalar postgresql96..."
	exit 0
fi
###		Fim Adição LCODING postgres-9.4

## Configuracao dos arquivos .conf para o Banco

mv /var/lib/pgsql/data/pg_hba.conf /var/lib/pgsql/data/pg_hba.conf.96
mv /var/lib/pgsql/data/postgresql.conf /var/lib/pgsql/data/postgresql.conf.96
cp -rfv "$LOCAL"/custom/pg_hba.conf /var/lib/pgsql/data
cp -rfv "$LOCAL"/custom/postgresql.conf /var/lib/pgsql/data

export HBACFG=/var/lib/pgsql/data/pg_hba.conf
export IPROUTE=`ip route show | grep kernel | awk '{ print $1 }' | head -1`
export IPHBA=`grep "192.168.0.0/24" "$HBACFG" | awk '{ print $4 }'`
export GROUTE=`grep "$IPROUTE" "$HBACFG" | awk '{ print $4 }'`

echo "
 "$HBACFG"
 "$IPHBA"
 "$IPROUTE"
"

if [ "$IPHBA" == "$IPROUTE" ]; then
        echo "IP pg_hba OK...."
  elif [ -f "$GROUTE" ] ; then
        echo "IP pg_hba OK..."
    else
        echo -e "\n\n# Conexao adicional IPv4 local\n" | tee -a "$HBACFG"
        echo -e "host all all "$IPROUTE" trust\n" | tee -a "$HBACFG"
        echo -e "\n..."

fi


## Configurando servico para postgresql

chkconfig postgresql-9.4 off 2> /dev/null
service postgresql-9.4 stop 2> /dev/null
chkconfig postgresql-9.4.4 off 2> /dev/null
service postgresql-9.4.4 stop 2> /dev/null
chkconfig postgresql off 2> /dev/null
service postgresql stop 2> /dev/null
chkconfig postgresql-9.6 off 2> /dev/null
service postgresql-9.6 stop 2> /dev/null

 if [ -e /usr/bin/systemctl ];then
	systemctl enable $PGSERV
	systemctl start $PGSERV
   else
	chkconfig $PGCHKC on
	service $PGCHKC start
 fi

## PACOTES
cd "$LOCAL"/custom/tgz/
chmod +x *.sh
./00_pacotes.sh
## PACOTES

## COMET
cd "$LOCAL"/custom/tgz/
chmod +x *.sh
./comet_install.sh
## COMET

$PGBIN/psql -p 5432 -U "$User" -c "ALTER USER "$User" WITH PASSWORD '"$Passwd"'" -d template1
su "$User" -c "createdb -U postgres "$DatabaseNameBase" "$DatabaseNameBase""

ldconfig

ZeusBD -ff "$LOCAL"/custom/function.sql


echo -e '\n
	Fim da instalação!
'



