#!/bin/bash

PGDG=10
yum-config-manager --disable pgdg* >> /dev/null
#yum-config-manager --enable pgdg"$PGDG" pgdg10  >> /dev/null
yum-config-manager --enable pgdg"$PGDG" >> /dev/null
yum -y install policycoreutils-python
#yum install pgadmin4-redhat-repo.noarch
rpm -qa | grep pgadmin4-redhat-repo-2-1 && echo OK || rpm -i https://ftp.postgresql.org/pub/pgadmin/pgadmin4/yum/pgadmin4-redhat-repo-2-1.noarch.rpm ;

yum updateinfo && yum -y --nogpgcheck makecache fast
yum -y --nogpgcheck install postgresql10-libs.x86_64
sed -i "s/^/#/" /etc/ld.so.conf.d/instant_client.conf
ldconfig
yum -y --nogpgcheck install pgadmin4-web
echo -e 'export PATH=/usr/local/apache2/bin:$PATH' | tee -a /etc/bashrc
export PATH=/usr/local/apache2/bin:$PATH

cp -v /usr/lib/systemd/system/httpd.service /usr/lib/systemd/system/httpd.service.bkp
chmod 000 /usr/lib/systemd/system/httpd.service.bkp
ln -sf /usr/lib/systemd/system/apache.service /usr/lib/systemd/system/httpd.service
systemctl daemon-reload

cp -av /usr/pgadmin4/web/config.py /usr/pgadmin4/web/config.py.bkp
sed -i "/DEFAULT_SERVER/s/127.0.0.1/0.0.0.0/g" /usr/pgadmin4/web/config.py
sed -i '/"pg":/s/\"\"/\"\/usr\/pgsql\/bin\"/g' /usr/pgadmin4/web/config.py
ln -sf /var/lib/pgadmin/storage /opt/pgadmin_storage

/usr/pgadmin4/bin/setup-web.sh


##      CUSTOM
#sed -i "1s/^/<VirtualHost *:80>\n/" /etc/httpd/conf.d/pgadmin4.conf
#echo -e '</VirtualHost>\n' | tee -a /etc/httpd/conf.d/pgadmin4.conf >> /dev/null

#echo -e "
#LOG_FILE = '/var/log/pgadmin/pgadmin4.log'
#SQLITE_PATH = '/var/lib/pgadmin/pgadmin4.db'
#SESSION_DB_PATH = '/var/lib/pgadmin/sessions'
#STORAGE_DIR = '/var/lib/pgadmin/storage'
#SERVER_MODE = True
#" | tee -a /usr/pgadmin4/web/config.py


#rm -rf /var/lib/pgadmin/ /var/log/pgadmin/ 2> /dev/null
#mkdir -p /var/lib/pgadmin/ /var/log/pgadmin/
#mkdir -p /var/lib/pgadmin/storage/postgres_postgres/
#chown -R apache:apache /var/lib/pgadmin /var/log/pgadmin

#chcon -t httpd_sys_rw_content_t /var/log/pgadmin -R
#chcon -t httpd_sys_rw_content_t /var/lib/pgadmin -R
#restorecon -R /var/lib/pgadmin/
#restorecon -R /var/log/pgadmin/
#setsebool -P httpd_can_network_connect_db 1
#setsebool -P httpd_can_network_connect 1

firewall-cmd --permanent --zone public --add-port 5050/tcp
#firewall-cmd --permanent --zone public --add-port 80/tcp
#firewall-cmd --permanent --zone public --add-port 443/tcp
firewall-cmd --reload

cat <<'EOF' > /etc/systemd/system/pgadmin4.service
[Unit]
Description=Pgadmin4 Service
After=network.target

[Service]
WorkingDirectory=/usr/pgadmin4/
Environment="PATH=/usr/pgadmin4/bin"
ExecStart=/usr/pgadmin4/venv/bin/python3 /usr/pgadmin4/web/pgAdmin4.py
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl stop pgadmin4
systemctl start pgadmin4
systemctl status pgadmin4

## PS:

# Após o comando "setup-web.sh", pede para acessar usando o endereço "http://0.0.0.0/pgadmin4", mas este pgadmin deve ser acessado com o endereço:

# http://0.0.0.0:5050

## PS2:

## Remover senha entrada PGAdmin:

#sed -i '/MASTER_PASSWORD_REQUIRED/s/True/False/' /usr/pgadmin4/web/config.py

## PS3:

## Rezetar e-mail e senha pgadmin4

#rm -rf /var/lib/pgadmin/pgadmin4.db
#/usr/pgadmin4/venv/bin/python3 /usr/pgadmin4/web/setup.py

# Definir: postgres@postgres.com:postgres

# restartar os serviços:

#systemctl stop pgadmin4
#systemctl stop apache
#systemctl start apache
#systemctl start pgadmin4

## PS4:

#Definir mais de 1 postgresql no pgadmin4:
#Configure no programa o caminho bin do pgsql:
#File > Preferences > Paths > Binary paths
#Salve o endereço e depois volte. Depois que voltar, selecione a versão que quer usar.

## PS5:

## Ao fazer backup, será salvo na pasta de usuário do pgAdmin 4. Na minha configuração fica neste local:

#/opt/pgadmin_storage/postgres_postgres.com


##      18.05.2021

#https://www.pgadmin.org/download/pgadmin-4-rpm/
#https://www.digitalocean.com/community/tutorials/como-instalar-e-configurar-o-pgadmin-4-no-modo-servidor-pt
#https://www.tecmint.com/install-postgressql-and-pgadmin-in-centos-8/
#https://www.pgadmin.org/docs/pgadmin4/development/connect_error.html
#https://stackoverflow.com/questions/42968708/i-cant-create-server-in-pgadmin4-http-127-0-0-15050-browser-on-ubuntu

#Dependência: */semanage
#Pacote: policycoreutils-python OU libsemanage-devel



##      pgAdmin4 + pgsql94:

# Ao usar pgsql versão 9.4, o serviço pgAdmin4 não inicia, devido às bibliotecas antigas com o seguinte erro:

# ...
#  CentOSIP10 python3[2726]: File "<frozen importlib._bootstrap_external>", line 678, in exec_module
#  CentOSIP10 python3[2726]: File "<frozen importlib._bootstrap>", line 219, in _call_with_frames_removed
#  CentOSIP10 python3[2726]: File "/usr/lib/python3.6/site-packages/pgadmin4-web/pgadmin/utils/driver/psycopg2/__init__.py", line 19, in <module>
#  CentOSIP10 python3[2726]: import psycopg2
#  CentOSIP10 python3[2726]: File "/usr/lib64/python3.6/site-packages/psycopg2/__init__.py", line 51, in <module>
#  CentOSIP10 python3[2726]: from psycopg2._psycopg import (                     # noqa
#  CentOSIP10 python3[2726]: ImportError: /usr/lib64/python3.6/site-packages/psycopg2/_psycopg.cpython-36m-x86_64-linux-gnu.so: undefined symbol: PQsslAttribute
#  CentOSIP10 systemd[1]: pgadmin4.service: main process exited, code=exited, status=1/FAILURE
#  CentOSIP10 systemd[1]: Unit pgadmin4.service entered failed state.
#  CentOSIP10 systemd[1]: pgadmin4.service failed.

# Correção:

# A seguinte biblioteca aponta uma das dependências para  a versão 94:

# ldd /usr/lib64/python3.6/site-packages/psycopg2/_psycopg.cpython-36m-x86_64-linux-gnu.so
# ...
# libpq.so.5 => /usr/pgsql-9.4/lib/libpq.so.5 (0x00007fbf87b59000)
# ...

# Há 2 arquivos que apontam a pasta de bibliotecas para o pgsql, em suas 2 versões:

# /etc/ld.so.conf.d/instant_client.conf:/usr/pgsql-9.4/lib/
# /etc/ld.so.conf.d/postgresql-pgdg-libs.conf:/usr/pgsql-10/lib/

# Deve editar o arquivo instant_client.conf para comentar (adicionar # na frente da linha) e dar o comando ldconfig.
# A biblioteca referida deve apontar para o pgsql correto:

# ldd /usr/lib64/python3.6/site-packages/psycopg2/_psycopg.cpython-36m-x86_64-linux-gnu.so
# ...
# libpq.so.5 => /usr/pgsql-10/lib/libpq.so.5 (0x00007fbf87b59000)
# ...

# Após fazer esta simples modificação, o pgAdmin4 será iniciado normalmente.

