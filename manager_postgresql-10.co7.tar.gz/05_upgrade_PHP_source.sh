#!/bin/bash

# php-5.6.40.tar.gz [18M]
# Fonte: https://www.php.net/releases/

# Fontes:
# https://blacksaildivision.com/php-install-from-source
# https://github.com/yoander/doc/blob/master/Nix/PHP/compile-php-5.6-centos-7.md
# https://github.com/r-dbi/RPostgres/issues/21
# https://www.postgresql.org/docs/9.1/libpq-build.html
# https://bugs.php.net/bug.php?id=66582
# http://qa.php.net/buildtest-process.php
# https://www.php.net/manual/pt_BR/install.unix.php
# https://www.gnu.org/software/bison/
# https://www.gnu.org/software/autoconf/
# https://www.gnu.org/software/automake/
# https://www.gnu.org/software/libtool/

## Dependências requeridas para o PHP:

# autoconf: 2.13+ (for PHP < 5.4.0), 2.59+ (for PHP >= 5.4.0), 2.64+ (for PHP >= 7.2.0) = (SOURCE)
# automake: 1.4+ = (SOURCE)
# libtool: 1.4.x+ (except 1.4.2) = (SOURCE)
# re2c: Version 0.13.4 or newer
# flex: Version 2.5.4 (for PHP <= 5.2)
# bison:
# PHP 5.4: 1.28, 1.35, 1.75, 1.875, 2.0, 2.1, 2.2, 2.3, 2.4, 2.4.1, 2.4.2, 2.4.3, 2.5, 2.5.1, 2.6, 2.6.1, 2.6.2, 2.6.4
# PHP 5.5: 2.4, 2.4.1, 2.4.2, 2.4.3, 2.5, 2.5.1, 2.6, 2.6.1, 2.6.2, 2.6.3, 2.6.4, 2.6.5, 2.7
# PHP 5.6: >= 2.4, < 3.0 = (SOURCE)
# PHP 7.0 - 7.3: 2.4 or later (including Bison 3.x)
# PHP 7.4: > 3.0

#autoconf --version
#autoconf (GNU Autoconf) 2.69
#automake --version
#automake (GNU automake) 1.13.4
#re2c --version
#re2c 0.14.3
#flex --version
#flex 2.5.37
#bison --version
#bison (GNU bison) 2.7

## PostgreSQL Manager = pgsql94

export PGSQL=`readlink -m /usr/pgsql-*`
export PGBIN=`ls -d /usr/pgsql*/b*/ | head -1`


export LD_LIBRARY_PATH=$PGSQL/lib/:$LD_LIBRARY_PATH
export LIBPQ_DIR=$PGSQL
export PKG_LIBS=$PGSQL/lib
export PKG_CONFIG_PATH=$PGSQL/lib/pkgconfig
export PKG_CPPFLAGS=$PGSQL/include

echo -e "
$PATH
$LD_LIBRARY_PATH
$LIBPQ_DIR
$PKG_LIBS
$PKG_CONFIG_PATH
$PKG_CPPFLAGS
"

read -p "Aperte ENTER para continuar..."

unlink /usr/lib64/pgsql &>> /dev/null
unlink /usr/include/pgsql &>> /dev/null
unlink /usr/pgsql &>> /dev/null
unlink /usr/bin/pg_config &>> /dev/null

ln -sf $PGSQL/lib /usr/lib64/pgsql
ln -sf $PGSQL/include /usr/include/pgsql
ln -sf $PGSQL /usr/pgsql
ln -sf $(readlink -m `ls "$PGSQL"/bin/*`) /usr/bin/
ln -sf $(readlink -m `ls /usr/local/apache2/bin/*`) /usr/bin/

yum-config-manager --disable pgdg* >> /dev/null
yum-config-manager --enable pgdg10 >> /dev/null
#yum-config-manager --enable pgdg14 >> /dev/null
yum updateinfo

echo -e "Instalando pacotes de compilacao GNU...\n"
read -t 5
yum --nogpgcheck -y install gcc gcc-c++ make flex libstdc++-devel perl perl-Data-Dumper

echo -e "Instalando pacotes de Dependências para compilacao do PHP...\n"
read -t 5
yum --nogpgcheck -y install re2c libxml2-devel bzip2-devel libcurl-devel libpng-devel libicu-devel libmcrypt-devel libwebp-devel libjpeg-devel krb5-devel openssl-devel pcre-devel sqlite-devel gd-devel readline-devel systemd-devel openldap-devel

#yum --nogpgcheck -y install libtool # O source do PHP já tem
#yum remove libtool autoconf automake perl-Test-Harness perl-Thread-Queue

read -p "Aperte ENTER para continuar..."
sleep 5

## bison:
#cp -rfv /opt/custom/sources/pacotes/bison-2.7.tar.gz /usr/src
#cd /usr/src
#tar -zxvf bison-2.7.tar.gz
#cd bison-2.7
#./configure
#make
#make install

# autoconf
#cp -rfv /opt/custom/sources/pacotes/autoconf-2.63.tar.gz /usr/src
#cd /usr/src
#tar -zxvf autoconf-2.63.tar.gz
#cd autoconf-2.63
#./configure
#make
#make install

# automake
#cp -rfv /opt/custom/sources/pacotes/automake-1.12.tar.gz /usr/src
#cd /usr/src
#tar -zxvf automake-1.12.tar.gz
#cd automake-1.12
#./configure
#make
#make install

# PHP

if [ -d /usr/local/php5 ]; then
cp -av /usr/local/php5/ /usr/local/php5_BKP
fi

#PEAR package PHP_Archive not installed: generated phar will require PHP's phar extension be enabled.

cd /usr/src
cp -rfv /opt/custom/sources/pacotes/php-5.6.40.tar.gz /usr/src


# PHP
export PATH=$PGBIN:$PATH
tar -zxvf php-5.6.40.tar.gz
cd php-5.6.40

read -p "Aperte ENTER para continuar..."
sleep 5

echo "Compilando pacote PHP"
sleep 5

## PHP Version 5.6.40 (SAAS)
# Adicionar: mod_ssl/2.2.34 OpenSSL/1.0.2k-fips

'./configure' '--prefix=/usr/local/php5' '--exec-prefix=/usr/local/php5' '--with-libdir=lib64' '--with-apxs2=/usr/local/apache2/bin/apxs' '--enable-mbstring' '--with-zlib' '--enable-zip' '--with-freetype-dir=/usr/include/freetype2/freetype' '--with-gd' '--enable-soap' '--enable-sockets' '--enable-sigchild' '--enable-bcmath' '--enable-exif' '--with-openssl' '--with-curl=/usr' '--with-jpeg-dir=/usr/lib' '--with-png-dir=/usr/lib' '--with-pcre-dir=/usr/lib' '--disable-cgi' '--enable-ftp' '--with-pgsql' '--with-pdo-pgsql' '--with-ldap' '--enable-pcntl' '--with-mysqli' '--with-pdo-mysql'

read -p "Aperte ENTER para continuar..."
sleep 5
################################################

echo "Marcando PHP"
sleep 5

make
#PEAR package PHP_Archive not installed: generated phar will require PHP's phar extension be enabled.
#make test
read -p "Aperte ENTER para continuar..."
sleep 5

echo "Instalando PHP"
sleep 5

make install
##rm -rf /root/.pearrc
read -p "Aperte ENTER para continuar, libtool..."
#libtool --finish /usr/src/php-5.6.36/libs
#libtool --finish /usr/local/apache2/modules
#/usr/local/bin/libtool --finish /usr/local/apache2/modules
/usr/src/php-5.6.40/libtool --finish /usr/local/apache2/modules

echo "Finalizando configuração"
sleep 5

echo -e '/usr/local/apache2/modules' | tee /etc/ld.so.conf.d/php56_modules.conf
#ln -sf /usr/local/Zend/etc/php.ini /usr/local/php/lib/php.ini
#cd /usr/local/php/lib/php/extensions/no-debug-non-zts-20131226/
#mv opcache.so opcache.so.bkp
#cp -rfv /usr/local/php_BKP/lib/php/extensions/no-debug-non-zts-20131226/* .
ln -sfv $(readlink -m `ls /usr/local/php5/bin/*`) /usr/bin/
ldconfig

cd /usr/src

read -p "Aperte ENTER para continuar..."
sleep 5

cat /etc/centos-release | tee /usr/src/info
uname -nor | tee -a /usr/src/info
psql --version | tee -a /usr/src/info
httpd -v | tee -a /usr/src/info
php -v | tee -a /usr/src/info

echo -e "Restartando o apache"

systemctl stop apache
systemctl start apache

read -t 3
echo -e '\nFim da compilacao!\n\n'

