#!/bin/bash

# export PS4='+${BASH_SOURCE}:${LINENO}:${FUNCNAME[0]}: '

if [ "$(id -u)" != "0" ]; then
echo "Deve executar o comando como super usuario!"
exit 0
fi

LOCAL=`pwd`

if [ ! "$LOCAL" == "/opt" ] ; then
	echo "O instalador deve estar na pasta /opt!"
	sleep 2
	exit 0
fi

LYNX='links -dump'
URLINFO='http://localhost/manager/info.php5'
MANAGERDIR='/usr/local/apache2/htdocs/manager'

INST='instalador_php_centos_pgsql_oracle'
PAC='zip'
export INST
export PAC

#echo -e "
#$LYNX
#$URLINFO
#$MANAGERDIR
#"

echo -e "\nExecutando instalacao do pacote ZeusRetail...\n"
sleep 5

###	ZeusRetail 1.7 off
cd /opt

if [ -e /usr/local/apache2/bin/apachectl ];then
/usr/local/apache2/bin/apachectl stop
pkill -9 httpd
sed -i 's/.\/apachectl/#.\/apachectl/g' /etc/rc.local
echo "Apache ZR1.7 off..."
grep 'apachectl' /etc/rc.local
read -t 5
fi

if [ -d /opt/Zanthus ];then
ls /Zanthus -l | grep ^l &>> /dev/null && \
        {
        unlink /Zanthus
}
fi

if [ -e /Zanthus ];then
ls /Zanthus -l | grep ^l &>> /dev/null && \
        {
	unlink /Zanthus
}
fi

if [ -e /var/lib/pgsql/bashprofile.tgz ] >> /dev/null ;then
echo '[ -f /etc/profile ] && source /etc/profile

PGDATA=/var/lib/pgsql/data
export PGDATA
' | tee /var/lib/pgsql/.bash_profile >> /dev/null
	read -t 5
	else
cd /var/lib/pgsql
tar -zcf bashprofile.tgz .bash_profile
cd - >> /dev/null
echo '[ -f /etc/profile ] && source /etc/profile

PGDATA=/var/lib/pgsql/data
export PGDATA
' | tee /var/lib/pgsql/.bash_profile >> /dev/null
	read -t 5
fi

###	ZeusRetail 1.7 off

#Limpamos as regras se quiserem depois inserem, a recomentação é que o servidor esteja protegido por uma vpn.
iptables -F
#Fazemos isso para conseguir usar o samba e o apache sem problemas de chon
if [ -d /sys/fs/selinux ];then
touch /sys/fs/selinux/enforce
echo '0' | tee /sys/fs/selinux/enforce >> /dev/null
fi

if [ -d /selinux ];then
touch /selinux/enforce
echo '0' | tee /selinux/enforce >> /dev/null
fi
  

cp -f "$INST"."$PAC" /usr/src

cd /usr/src

echo -e "Descompactando instalador"
mkdir -p "$INST"
un"$PAC" -uq "$INST"."$PAC"

#####		Script instalar compilados
##	bash "$INST"/instalar_compilados.sh 

echo "Iniciando a instalação do servidor"
cd /usr/src

#Para configurar a internet use nmtui

echo "Saindo do diretório"
cd /


echo "Descompactando InstantClient"
tar -xzmf /usr/src/"$INST"/instalar_instant_client_12_2.tar.gz
echo "Descompactando libEvent"
tar -xzmf /usr/src/"$INST"/instalar_libevent_centos_6_5.tar.gz
echo "Descompactando memcached"
tar -xzmf /usr/src/"$INST"/instalar_memcached_centos_6_5.tar.gz
echo "Descompactando node"
tar -xzmf /usr/src/"$INST"/instalar_node_centos_6_5.tar.gz
echo "Descompactando Zend"
tar -xzmf /usr/src/"$INST"/instalar_zend_php_centos_6.5.tar.gz
echo "Descompactando apr"
tar -xzmf /usr/src/"$INST"/instalar_apr_centos_6_5.tar.gz
echo "Descompactando php"
tar -xzmf /usr/src/"$INST"/instalar_php_centos_7_7.tar.gz
echo "Descompactando Apache"
tar -xzmf /usr/src/"$INST"/instalar_apache_centos_7_7.tar.gz
echo "Descompactando FreeTDS"
tar -xzmf /usr/src/"$INST"/instalar_freetds_centos_7_7.tar.gz

#echo "Criando links e copiando arquivos"
#cd /usr/src
#cp  -f "$INST"/bibliotecas_zanthus.conf /etc/ld.so.conf.d/.
#cp  -f "$INST"/instant_client.conf /etc/ld.so.conf.d/.
#cp  -f "$INST"/index.html /usr/local/apache2/htdocs/.

#cp -f "$INST"/apachectl /usr/local/apache2/bin/apachectl
#cp -f "$INST"/memcached /usr/src/.
#cp -f "$INST"/memcached.conf /etc/sysconfig/memcached
#cp -f "$INST"/apache.conf /etc/sysconfig/httpd


#chmod +x memcached
#mkdir -p /usr/local/Zend
#mkdir -p /usr/local/Zend/etc
#mkdir -p /var/run/memcached
#chmod 777 /var/run/memcached
#mkdir -p /run/memcached
#chmod 777 /run/memcached

#cp -f "$INST"/php.ini /usr/local/Zend/etc/.
#cp -f "$INST"/memcached.service /usr/lib/systemd/system/.
#cp -f "$INST"/apache.service /usr/lib/systemd/system/.
##	O php precisa ter o mesmo caminho do módulo php no apache
#ln -sf /usr/local/Zend/etc/php.ini  /usr/local/php/lib/php.ini
#ln -sf /usr/local/php/bin/php /usr/bin/php 
#ln -sf /usr/local/php/bin/php-config /usr/bin/php-config 
#ln -sf /usr/local/php/bin/phpize /usr/bin/phpize 
#ln -sf /usr/local/memcached/bin/memcached /usr/bin/memcached
#ln -sf /usr/local/apache2/bin/apachectl /etc/init.d/apache
#ln -sf /usr/src/libevent-2.0.22-stable/.libs/libevent-2.0.so.5 /lib64/libevent-2.0.so.5
#ln -sf /usr/local/apr/lib/libaprutil-1.so.0 /lib64/libaprutil-1.so.0
#ln -sf /usr/local/node/bin/node /usr/bin/node
#ln -sf /usr/src/memcached /etc/init.d/memcached
#ln -sf /etc/init.d/memcached /etc/rc3.d/S99memcached
#ln -sf /etc/init.d/apache /etc/rc3.d/S99apache
#ln -sf /usr/local/apache2/htdocs /web

## Correção para "/etc/init.d/functions"
ls -1 /etc/init.d/
#read -p "Verificar se tem o functions..."
if [ ! -e /etc/init.d/functions ]; then
ln -s /etc/rc.d/init.d/functions /etc/init.d/functions
fi

##

ldconfig 
echo "vamos colocar os serviços para inicializar com o chkConfig"

systemctl daemon-reload

chkconfig --add memcached
systemctl enable memcached
chkconfig memcached on

chkconfig --add apache
systemctl enable apache
chkconfig apache on


echo "vamos subir o serviço do Memcached"
service memcached start

echo "criando usuário"
adduser zanthus

cd /usr/src
mkdir libs_zanthus
chown zanthus:zanthus -R libs_zanthus

ln -s /usr/local/apache2 /usr/local/apache2

##	MANAGER
if [ -f "$MANAGERDIR/info.php5" ]; then
	systemctl start apache
	APACHE='1'
 $LYNX $URLINFO | grep -i 'Manager:'
        echo -e '
 Deseja atualizar agora para a última versão?'
        read -p " Responda [s(sim)|N (NÃO)]: " MANAGER
        echo $MANAGER
case "$MANAGER" in
        [sS])
php -f /usr/src/"$INST"/baixar_bibliotecas_ftp.php5 "/Zanthus/"
cd /usr/src/libs_zanthus
ldconfig
cd -
        ;;
	[nN])
	echo "Mantendo versão instalada do Manager..."
	sleep 5
        ;;
	*)
	echo "Mantendo versão instalada do Manager..."
	sleep 5
        ;;
esac
 else
php -f /usr/src/"$INST"/baixar_bibliotecas_ftp.php5 "/Zanthus/"
cd /usr/src/libs_zanthus
ldconfig
cd -
fi
##	MANAGER FIM

##	ZMWSInfo.ini
if [ -e $MANAGERDIR/ZMWSInfo.ini ]; then
ParametroZM(){
	clear
	echo -e '
 Arquivo ZMWSInfo.ini já existe.
 Responda 1 para manter e continuar a configuração...
 Responda 2 para reconfigurar e sobrescrever o arquivo.
'
read -p "[1] Manter, [2] Recofigurar: " ZMWSINFO
case $ZMWSINFO in
        1)
	echo "Mantendo ZMWSInfo.ini e prosseguindo com a configuração..."
	clear
	;;
	2)
mv $MANAGERDIR/ZMWSInfo.ini $MANAGERDIR/ZMWSInfo.ini.bkp
cd /usr/src
php -f /usr/src/"$INST"/configurar_zmwsinfo.php5 "/usr/local"
clear
        ;;
	*) "Opcao invalida" ; echo ; ParametroZM ;;
esac
}
ParametroZM
  else
cd /usr/src
php -f /usr/src/"$INST"/configurar_zmwsinfo.php5 "/usr/local"
fi
##	ZMWSInfo.ini

##	Download manual do Manager Web para testes
# Manager Web 128 estava corrompido no dia do teste (atualmente corrigido)

#echo -e '\n\n'

#cd $MANAGERDIR

#    export file='ManagerWEB_2_14_126_119e-20094_php_5_6."$PAC"'
#    export url="ftp://ftp.zanthus.com.br:2142/pub/Zeus_Retail/WEB/$file"
#    echo -n "Baixando "$file""
#    wget -c --progress=dot:force $url 2>&1 | grep --line-buffered "%" | \
#        sed -u -e "s,\.,,g" | awk '{printf("\b\b\b\b%4s", $2)}'
#    echo -ne "\b\b\b\b"
#    echo " DONE"

#echo -e "Descompactando "$file""
#un"$PAC" -oq "$file"
#echo -e '\n\n'

##	Download manual do Manager Web para testes - FIM

##	Teste manual do ZMWSInfo.ini

#cp -rfv /opt/custom/ZMWSInfo.ini $MANAGERDIR/ZMWSInfo.ini

##	Teste manual do ZMWSInfo.ini - FIM





echo -e '\n\n'


cp -Rf /etc/samba/smb.conf /etc/samba/smb.conf_bkp
cp -Rf /usr/src/"$INST"/smb_exemplo.conf /etc/samba/smb.conf
chkconfig smb on
service smb start

echo "vamos subir o serviço Apache"
if [ "$APACHE" == "1" ]; then
#service apache start
systemctl restart apache
 else
systemctl start apache
fi

rm -rf /usr/src/"$INST"/
rm -rf /usr/src/"$INST"."$PAC"

mkdir -p /Zanthus/Zeus/path_comum
touch /Zanthus/Zeus/path_comum/path_comum_ok_pode_me_apagar.txt

#http://www.linuxbrigade.com/reduce-time_wait-socket-connections/
echo 30 > /proc/sys/net/ipv4/tcp_fin_timeout
#echo 1 > /proc/sys/net/ipv4/tcp_tw_recycle
echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse

echo "# Decrease TIME_WAIT seconds
net.ipv4.tcp_fin_timeout = 30
" >> /etc/sysctl.conf

echo "# Recycle and Reuse TIME_WAIT sockets faster
#net.ipv4.tcp_tw_recycle = 1
net.ipv4.tcp_tw_reuse = 1
" >> /etc/sysctl.conf

sysctl -p

if grep -E 'CentOS.*release 8\.' /etc/centos-release &>> /dev/null ; then
	systemctl restart NetworkManager.service
  else
	service network restart
fi

echo "fim"

#####		Script instalar compilados

##
echo -e 'links -dump http://localhost/manager/info.php5 | grep -i 'Manager:' ; php --version' | tee /usr/bin/manager-version >> /dev/null
chmod +x /usr/bin/manager-version
##

sleep 5

echo -e "\n\n
Fim da configuracao...
Execute agora o terceiro script (Inicializacao)!
"


