#!/bin/bash

# https://www.cyberciti.biz/faq/delta-rpms-disabled-because-applydeltarpm-not-installed/

if [ "$(id -u)" != "0" ]; then
echo "Deve executar o comando como super usuario!"
exit 0
fi

LOCAL=`pwd`

if [ ! "$LOCAL" == "/opt" ] ; then
	echo "O instalador deve estar na pasta /opt!"
	sleep 2
	exit 0
fi

pkill -9 [Pp][Aa][Cc][Kk][Aa][Gg][Ee]

echo -e "\nExecutando instalacao dos pacotes e dependencias para o Manager...\n"
sleep 5


if grep -E 'CentOS.*release 8\.' /etc/centos-release &>> /dev/null ; then
        export COID='8'
#        	echo -e "A partir do CentOS 8.X não se usa mais \"yum\", usa dnf..."
#        		exit 0
	function yum () { dnf "$@"; }
  elif grep -E 'CentOS.*release 7\.' /etc/centos-release &>> /dev/null ; then
        export COID='7'
    elif grep -E 'CentOS.*release 6\.' /etc/centos-release &>> /dev/null  ; then
        export COID='6'
        	echo -e "CentOS 6.X não possui init preparado para esta versão!"
        		exit 0
 else
     	echo "Erro..."
        exit 0
fi

## Versão do postgresql
# No CentOS 8, deve ativar a versão a partir do 10, por não existir o pacote server e principal do 9X
#if [ "$COID" -eq "8" ]; then
#PGDG='96'
#PGDGS='9.6'
#  else
PGDG='10'
#fi

# Instalando repositório epel e aplicativo complementar yum-utils
yum -y install epel-release yum-utils deltarpm

if yum list installed epel-release* &>>/dev/null; then
        echo -e "epel-release OK"
  else
      	echo -e "Repositório epel-release não foi instalado..."
	echo -e "Instale manualmente o repositório antes E/OU Rode novamente o Script!"
	exit 0
fi

###

if [ "$COID" -eq "6" ]; then
## Instalando repositório para PostgreSQL+PGAdmin
#yum --nogpgcheck -y install https://download.postgresql.org/pub/repos/yum/reporpms/EL-6-x86_64/pgdg-redhat-repo-latest.noarch.rpm
	echo "A instalação não tem mais suporte para a versão 6 do CentOS!"
		exit 0
## Atualizando repositórios e atualizando pacotes
yum check-update && yum --nogpgcheck -y update
   elif [ "$COID" -eq "7" ]; then
## Instalando repositório para PostgreSQL+PGAdmin
yum --nogpgcheck -y install https://download.postgresql.org/pub/repos/yum/reporpms/EL-7-x86_64/pgdg-redhat-repo-latest.noarch.rpm
## Atualizando repositórios e atualizando pacotes
yum updateinfo && yum --nogpgcheck -y update
   elif [ "$COID" -eq "8" ]; then
## Instalando repositório para PostgreSQL+PGAdmin
# yum --nogpgcheck -y install https://download.postgresql.org/pub/repos/yum/reporpms/EL-8-x86_64/pgdg-redhat-repo-latest.noarch.rpm
	echo -e "CentOS 8 \"End-of-life, 31 December 2021\""
	echo -e "Acesse: https://blog.centos.org/2020/12/future-is-centos-stream/"
	sleep -2
		exit 0
## Atualizando repositórios e atualizando pacotes
yum updateinfo && yum --nogpgcheck -y update
 else
     	echo "Erro..."
        exit 0
fi

if yum list installed pgdg* &>>/dev/null; then
        echo " pgdg-redhat-repo-latest.noarch OK"
  else
      	echo -e "Repositório pgdg-redhat-repo-latest.noarch não foi instalado..."
	echo -e "Instale manualmente o repositório antes E/OU Rode novamente o Script!"
	exit 0
fi

###

## Desativando repositórios desnecessários e configurando sistema para suportar pacotes multi arquitetura
yum-config-manager --disable pgdg* >> /dev/null
yum-config-manager --enable pgdg"$PGDG" >> /dev/null
yum-config-manager --save --setopt=protected_multilib=false >> /dev/null

## atualizando cache de pacotes
if [ "$COID" -eq "8" ]; then
yum-config-manager --enable PowerTools  >> /dev/null
	yum makecache
  else
	yum makecache fast
fi

read -p "Aperte ENTER para continuar..."

## Dependencias do instalador Zeus Retail a ser instalados:
#libpng12
#libpng
#libjpeg
#libhugetlbfs
#links
#telnet
#strace
#libldb
#openldap
#libaio

## Dependência do comando php:
# libmcrypt

## Dependencias para dar suporte ao lnx_conv dos PDVs Linux 32 bits (Deve ter a pasta lib com bibliotecas 32 bits em /ZanthusZeus)
#glibc.i686
#libxml2.i686

## Opcional
#mlocate

## Instalando dependências Manager e PostgreSQL+PGAdmin
# Para quem usa banco Oracle, não precisa instalar os pacotes PostgreSQL+PGAdmin
#PACOTES
yum --nogpgcheck install net-tools \
nano \
openssl \
curl \
telnet \
libxml2 \
unzip \
wget \
dos2unix \
samba \
samba-winbind \
libpng12 \
libpng \
libjpeg \
libhugetlbfs \
strace \
libldb \
openldap \
libaio \
libmcrypt \
glibc.i686 \
libxml2.i686 \
mlocate

if [ "$COID" -eq "8" ]; then
# Desativando instalação do postgresql em módulo
dnf -qy module disable postgresql
# Instalando Postgresql do repositório "PGDG"
# https://www.postgresql.org/download/linux/redhat/
yum --nogpgcheck install compat-openssl10 \
libnsl \
libpng15 \
elinks \
postgresql"$PGDG".x86_64 \
postgresql"$PGDG"-devel.x86_64 \
postgresql"$PGDG"-libs.x86_64 \
postgresql"$PGDG"-server.x86_64
#@postgresql:"$PGDGS" \
#postgresql"$PGDG"-libs.x86_64
#PGSQL=`readlink -m /usr/pgsql-* | tail -n1`
#ln -s /usr/bin "$PGSQL"/bin
  else
yum --nogpgcheck install links \
openssl098e \
postgresql"$PGDG".x86_64 \
postgresql"$PGDG"-devel.x86_64 \
postgresql"$PGDG"-libs.x86_64 \
postgresql"$PGDG"-server.x86_64
fi

#PACOTES

ldconfig
updatedb


if yum list installed postgresql"$PGDG"* &>>/dev/null; then
        echo "postgresql"$PGDG" OK"
  else
      	echo -e "Pacote postgresql"$PGDG" não foi instalado..."
	echo -e "Instale manualmente o pacote antes E/OU Rode novamente o Script!"
	exit 0
fi


read -p "Aperte ENTER para continuar..."

## Variáveis para postgresql
# CentOS 6:
basename $(rpm -ql `rpm -qa | grep -E "postgresql.*server"` | grep -E "init.*postgresql") &>> /dev/null && \
        {
                export PGSERV="$(basename $(rpm -ql `rpm -qa | grep -E "postgresql.*server"` | grep -E "init.*postgresql"))"
		PGID='6'
}

# CentOS 7+
basename $(rpm -ql `rpm -qa | grep -E "postgresql.*server"` | grep -E "postgresql.*service") &>> /dev/null && \
        {
                export PGSERV="$(basename $(rpm -ql `rpm -qa | grep -E "postgresql.*server"` | grep -E "postgresql.*service"))"
		PGID='7'
}

export PGID

#
export PGSQL=`readlink -m /usr/pgsql-* | tail -n1`
#export PGSQL=`ls -d /usr/pgsql*/`
#export PGLIB=`ls -d /usr/pgsql*/l*/`
export PGBIN=`ls -d /usr/pgsql*/b*/ | tail -n1`


echo -e "
Servico: $PGSERV
Diretorios:
Aplicacao $PGSQL
Binario $PGBIN
"
## Variáveis para postgresql

## postgresql

#export LD_LIBRARY_PATH=$PGSQL/lib/:$LD_LIBRARY_PATH
#export PATH=$PGBIN:$PATH
#export LIBPQ_DIR=$PGSQL
#export PKG_LIBS=$PGSQL/lib
#export PKG_CONFIG_PATH=$PGSQL/lib/pkgconfig
#export PKG_CPPFLAGS=$PGSQL/include

unlink /usr/lib64/pgsql 2>> /dev/null
unlink /usr/include/pgsql 2>> /dev/null
ln -sf $PGSQL/lib /usr/lib64/pgsql
ln -sf $PGSQL/include /usr/include/pgsql
ln -sf $PGSQL /usr/pgsql
ln -sf $PGSQL/bin/pg_config /usr/bin/pg_config


if ( grep "export PATH=$PGBIN:\$PATH" /etc/bashrc ) >> /dev/null ; then
	read -t 0
	source /etc/bashrc
  else
	echo "export PATH=$PGBIN:\$PATH" | tee -a /etc/bashrc
	source /etc/bashrc
fi

chkconfig --add "$PGSERV" 2>> /dev/null

if [ "$PGID" -eq "6" ]; then
	chkconfig "$PGSERV" on
        service "$PGSERV" status
   elif [ "$PGID" -eq "7" ]; then
        systemctl enable "$PGSERV"
        systemctl status "$PGSERV"
 else
     	echo "Servico nao encontrado..."
        exit 0
fi



## postgresql

psql --version
read -t 5

echo -e '\n
Fim da configuracao...
Execute agora o segundo script (Aplicacao)!
'





